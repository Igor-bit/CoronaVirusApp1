package com.igorcordeiroszeremeta.coronavirusapp1;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    int resultado = 0;
    private CheckBox febre;
    private CheckBox tosseSeca;
    private CheckBox cansaco;
    private CheckBox doresEDesconfortos;
    private CheckBox dorDeGarganta;
    private CheckBox diarreia;
    private CheckBox conjuntivite;
    private CheckBox dorDeCabeca;
    private CheckBox perdaDePaladarOuOlfato;
    private CheckBox erupcaoCutanea;
    private CheckBox dificuldadesParaRespirar;
    private CheckBox dorOuPressaoNoPeito;
    private CheckBox perdaDeFalaOuPerdaDeMovimento;
    private TextView textoDoResultadoFinal;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        febre = findViewById(R.id.febre);
        tosseSeca = findViewById(R.id.tosseSeca);
        cansaco = findViewById(R.id.cansaco);
        doresEDesconfortos = findViewById(R.id.doresEDesconfortos);
        dorDeGarganta = findViewById(R.id.dorDeGarganta);
        diarreia = findViewById(R.id.diarreia);
        conjuntivite = findViewById(R.id.conjuntivite);
        dorDeCabeca = findViewById(R.id.dorDeCabeca);
        perdaDePaladarOuOlfato = findViewById(R.id.perdaDePaladarOuOlfato);
        erupcaoCutanea = findViewById(R.id.erupcaoCutanea);
        dificuldadesParaRespirar = findViewById(R.id.dificuldadesParaRespirar);
        dorOuPressaoNoPeito = findViewById(R.id.dorOuPressaoNoPeito);
        perdaDeFalaOuPerdaDeMovimento = findViewById(R.id.perdaDeFalaOuPerdaDeMovimento);
        textoDoResultadoFinal = findViewById(R.id.textoDoResultadoFinal);
    }

    public int calcularResultado() {

        if (febre.isActivated()) {
            resultado += 1;

        } else if (tosseSeca.isActivated()) {
            resultado += 1;

        } else if (cansaco.isActivated()) {
            resultado += 1;

        } else if (doresEDesconfortos.isActivated()) {
            resultado += 3;

        } else if (dorDeGarganta.isActivated()) {
            resultado += 3;

        } else if (diarreia.isActivated()) {
            resultado += 3;

        } else if (conjuntivite.isActivated()) {
            resultado += 3;

        } else if (dorDeCabeca.isActivated()) {
            resultado += 3;

        } else if (perdaDePaladarOuOlfato.isActivated()) {
            resultado += 3;

        } else if (erupcaoCutanea.isActivated()) {
            resultado += 3;

        } else if (dificuldadesParaRespirar.isActivated()) {
            resultado += 20;

        } else if (dorOuPressaoNoPeito.isActivated()) {
            resultado += 20;

        } else if (perdaDeFalaOuPerdaDeMovimento.isActivated()) {
            resultado += 20;
        }
        return resultado;
    }

    int resultadoDoTeste = calcularResultado();

    public void resultadoFinalDoTeste(int resultadoDoTeste) {

        if (resultadoDoTeste <= 7) {
            textoDoResultadoFinal.setText("Você apresenta os sintomas leves. Por favor, se cuide.");

        } else if (resultadoDoTeste <= 20) {
            textoDoResultadoFinal.setText("Você apresenta os sintomas medianos. Tome cuidado. Em caso de piora, por favor, procure urgentemente uma unidade de saúde.");

        } else {
            textoDoResultadoFinal.setText("Você apresenta os sintomas graves. Por favor, procure imediatamente uma unidade de saúde");
        }
    }
}